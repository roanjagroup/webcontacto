//js global
$(document).ready(function(){    

    $('#btn-enviar').click(function(){
    	//confirm('Esta seguro de realizar esta operación?');
    	//alert('clases/ContactController.php'); 

        //var url = 'clases/ContactController.php';
        $.ajax({                        
           type: "POST",                 
           url: 'clases/ContactController.php',                     
           data: $("#contact-form").serialize(), 
           success: function(response)             
           {
           	 alert(response);
             $('#mensaje').html(response);               
           }
       });
    });
});
