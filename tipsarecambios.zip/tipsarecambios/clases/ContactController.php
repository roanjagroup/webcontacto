<?php
	 
	


	 $razonSocial = $_POST['razonSocial'];
	 $cif = $_POST['cif'];
	 $provincia = $_POST['provincia'];
	 $codigo_postal = $_POST['codigoPostal'];
	 $poblacion = $_POST['poblacion'];
	 $direccion = $_POST['direccion'];
	 $telefono = $_POST['telefono'];
	 $email = $_POST['email'];
	 $personaContacto = $_POST['personaContacto'];
	 $solicita_comercial = $_POST['solicitaComercial'];
	 $autoriza_email = $_POST['autorizaEmail'];
	 $reenviame = $_POST['reenviame'];

	 //$query = "INSERT INTO tipsarecambios "


	 function listarProvincias(){
	 	$query = 'SELECT id, provincia FROM provincias ORDER BY provincia';
	 	$result = $db->query($query);
		while($provincias = mysqli_fetch_row($result)){
			echo '<option value="'.$provincias["id"].'">'.$provincias["provincia"].'</option>';
		}
	}
?>