<?php 

/**
 * 
 */
class Contact
{
	
	function __construct()
	{
		# code...
	}

	function listarProvincias(){
	 	$query = 'SELECT provincia FROM provincias ORDER BY provincia';
	 	$result = $db->query($query);
		$provincias = mysqli_fetch_row($result);

		return $provincias;
	}

}


 ?>