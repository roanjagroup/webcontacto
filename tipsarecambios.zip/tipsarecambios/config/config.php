<?php

$currentDir = dirname(__FILE__);
require_once($currentDir.'/defines.php');
require_once(_ROOT_CONFIG_.'conex.php');
