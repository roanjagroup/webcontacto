<?php
/*
* Autor: Romell Jaramillo
* email: romelljaramillo@gmail.com
*
*/
/* conexción remoto
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'incidencias');
define('_DB_USER_', 'root');
define('_DB_PASSWD_', 'Itrps#15');
define('_DB_CHARSET_','utf-8'); 
*/

/*conexción Local*/
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'incidencias');
define('_DB_USER_', 'root');
define('_DB_PASSWD_', '');
define('_DB_CHARSET_','utf-8'); 