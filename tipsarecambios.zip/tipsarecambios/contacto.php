<?php 
    require_once($_SERVER['DOCUMENT_ROOT'].'/intranet/tipsarecambios/config/config.php');
    include (_ROOT_THEME_."head.php");
    include (_ROOT_THEME_."formContact.php");
    include (_ROOT_THEME_."footer.php");
?>