<main role="main">      
    <div class="jumbotron">
        <div class="container">
          <h1 class="display-4">Formulario de contacto</h1>
          <p>Especialistas en transporte de recambios de automoción.</p>          
        </div>
    </div>
    <div class="container">
        <div id="mensaje"></div>
        <form id="contact-form">
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="razonSocial">Razón social</label>
                    <input type="text" name="razonSocial" class="form-control" id="razonSocial" placeholder="">
                </div>
                <div class="form-group col-md-6">
                    <label for="cif">CIF/NIF.</label>
                    <input type="text" name="cif" class="form-control" id="cif" placeholder="">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="provincia">Provincia</label>                            
                    <select name="provincia" id="provincia" class="form-control">
                        <option selected="">Seleccione...</option>
                        <option>...</option>
                    </select>
                </div>
                <div class="form-group col-md-2">
                    <label for="codigoPostal">Código Postal</label>
                    <input type="text" name="codigoPostal" class="form-control" id="codigoPostal" placeholder="">
                </div>
                <div class="form-group col-md-3">
                    <label for="poblacion">Población</label>
                    <input type="text" name="poblacion" class="form-control" id="poblacion" placeholder="">
                </div>
                <div class="form-group col-md-4">
                    <label for="direccion">Dirección</label>
                    <input type="text" name="direccion" class="form-control" id="direccion">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="telefono">Teléfono</label>
                    <input type="text" name="telefono" class="form-control" id="telefono">
                </div>
                <div class="form-group col-md-4">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" id="email">
                </div>
                <div class="form-group col-md-4">
                    <label for="personaContacto">Persona de contacto</label>
                    <input type="text" name="personaContacto" class="form-control" id="personaContacto">
                </div>
            </div>
            <div class="form-group">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="solicitaComercial" id="solicitaComercial">
                    <label class="form-check-label" for="solicitaComercial">
                        Solicita visita comencial
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="autorizaEmail" id="autorizaEmail">
                    <label class="form-check-label" for="autorizaEmail">
                        Autoriza que le envien tarifas por e-mail
                    </label> 
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="reenviame" id="reenviame">
                    <label class="form-check-label" for="reenviame">
                        Reenviame este email
                    </label>                   
                </div>
            </div>
            <button type="button" id="btn-enviar" class="btn btn-primary pull-right">Enviar formulario</button>  
        </form>
    </div>
</main>